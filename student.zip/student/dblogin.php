<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$dbname = "student_db";

	//establish connection to database
	$mysqli = mysqli_connect($host, $user, $pass, $dbname);

?>